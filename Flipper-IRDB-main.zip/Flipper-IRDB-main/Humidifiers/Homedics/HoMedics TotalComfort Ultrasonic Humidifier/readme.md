HoMedics TotalComfort Ultrasonic Humidifier (model #1537669, Costco 2022)
